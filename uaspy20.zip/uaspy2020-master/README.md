# Project UAS Bahasa Pemrograman
![Annotation 2020-01-19 090839](https://user-images.githubusercontent.com/57013284/72673332-68c05b00-3a9b-11ea-8bc9-0905e5dd25c3.png)
gambar screenshot program

Pada class MainApp, lakukan overriding terhadap method:
a. list_book(): buat instance class ViewBook() dan call method list()
b. add_book(): buat instance class InputBook() dan call method input(), lalu hasilnya tambahkan
pada attribute books
c. search_book(): buat instance class InputBook() dan call method search(), kemudian buat
instance class SearchHelper() dan call method search_title(), kemudian buat instance class
ViewBook dengan parameter books dari search_title() dan panggil method list()


